module.exports = {
  // vue版本选项 true - 完全版 false - 运行时版
  runtimeCompiler: false
}