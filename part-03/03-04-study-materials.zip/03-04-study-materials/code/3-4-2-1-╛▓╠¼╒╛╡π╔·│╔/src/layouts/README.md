Layout components are used to wrap pages and templates. Layouts should contain components like headers, footers or sidebars that will be used across the site.

Learn more about Layouts: https://gridsome.org/docs/layouts/

You can delete this file.
