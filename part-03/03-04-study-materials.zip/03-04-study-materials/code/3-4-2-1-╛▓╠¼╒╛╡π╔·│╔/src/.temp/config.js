export default {
  "trailingSlash": true,
  "pathPrefix": "",
  "titleTemplate": "%s - 拉勾教育",
  "siteUrl": "",
  "version": "0.7.19",
  "catchLinks": true
}