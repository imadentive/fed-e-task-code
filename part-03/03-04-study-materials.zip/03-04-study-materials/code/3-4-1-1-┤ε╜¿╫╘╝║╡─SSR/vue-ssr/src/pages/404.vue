<template>
  <div>
    <h1>404 Not Page</h1>
  </div>
</template>

<script>
export default {
  name: 'Error404'
}
</script>

<style>

</style>
